<?php
/**
 * Inventory tabs template.
 *
 * @package steam-game-inventory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="sgi-inventory" data-component="sgi-inventory">
	<div class="sgi-inventory__header">
		<h2 class="sgi-inventory__title"><?php echo esc_html__( 'Game Inventories', 'steam-game-inventory' ); ?></h2>
		<p class="sgi-inventory__subtitle"><?php echo esc_html__( 'Browse your Dota 2, CS2, and TF2 collections.', 'steam-game-inventory' ); ?></p>
	</div>

	<div class="sgi-tabs" role="tablist" aria-label="<?php echo esc_attr__( 'Steam game tabs', 'steam-game-inventory' ); ?>">
		<button class="sgi-tabs__button is-active" data-appid="570" role="tab" aria-selected="true"><?php echo esc_html__( 'Dota 2', 'steam-game-inventory' ); ?></button>
		<button class="sgi-tabs__button" data-appid="730" role="tab" aria-selected="false"><?php echo esc_html__( 'CS2', 'steam-game-inventory' ); ?></button>
		<button class="sgi-tabs__button" data-appid="440" role="tab" aria-selected="false"><?php echo esc_html__( 'TF2', 'steam-game-inventory' ); ?></button>
		<span class="sgi-tabs__indicator" aria-hidden="true"></span>
	</div>

	<div class="sgi-inventory__content" data-inventory-content>
		<div class="sgi-grid sgi-grid--skeleton" data-skeleton>
			<?php for ( $i = 0; $i < 6; $i++ ) : ?>
				<div class="sgi-card sgi-card--skeleton"></div>
			<?php endfor; ?>
		</div>
	</div>
</div>
