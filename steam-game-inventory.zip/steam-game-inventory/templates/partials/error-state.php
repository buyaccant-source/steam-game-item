<?php
/**
 * Error state partial.
 *
 * @var string $error_code Error code.
 * @var string $message Error message.
 * @package steam-game-inventory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="sgi-error" data-error="<?php echo esc_attr( $error_code ); ?>">
	<div class="sgi-error__icon" aria-hidden="true">⚠</div>
	<div class="sgi-error__content">
		<h3 class="sgi-error__title"><?php echo esc_html__( 'Inventory Notice', 'steam-game-inventory' ); ?></h3>
		<p class="sgi-error__message"><?php echo esc_html( $message ); ?></p>
	</div>
</div>
