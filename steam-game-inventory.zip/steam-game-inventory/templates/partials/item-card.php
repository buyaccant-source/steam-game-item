<?php
/**
 * Item card partial.
 *
 * @var array<string,mixed> $item Item payload.
 * @package steam-game-inventory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$primary_meta   = '';
$secondary_meta = '';

if ( 570 === (int) $item['appid'] ) {
	$primary_meta   = ! empty( $item['hero'] ) ? $item['hero'] : $item['type'];
	$secondary_meta = ! empty( $item['rarity'] ) ? $item['rarity'] : '';
}

if ( 730 === (int) $item['appid'] ) {
	$primary_meta = ! empty( $item['weapon'] ) ? $item['weapon'] : $item['type'];
	$skin         = ! empty( $item['skin'] ) ? $item['skin'] : '';
	$exterior     = ! empty( $item['exterior'] ) ? $item['exterior'] : '';
	$secondary_meta = trim( $skin . ( $skin && $exterior ? ' · ' : '' ) . $exterior );
}

if ( 440 === (int) $item['appid'] ) {
	$primary_meta   = ! empty( $item['quality'] ) ? $item['quality'] : $item['type'];
	$secondary_meta = ! empty( $item['type'] ) ? $item['type'] : '';
}
?>
<article class="sgi-card" data-rarity-color="<?php echo esc_attr( $item['rarity_color'] ); ?>">
	<div class="sgi-card__image-wrap">
		<?php if ( ! empty( $item['icon_url'] ) ) : ?>
			<img class="sgi-card__image" src="<?php echo esc_url( $item['icon_url'] ); ?>" alt="<?php echo esc_attr( $item['item_name'] ); ?>" loading="lazy" />
		<?php else : ?>
			<div class="sgi-card__image-placeholder"></div>
		<?php endif; ?>
	</div>
	<h3 class="sgi-card__title"><?php echo esc_html( $item['item_name'] ); ?></h3>
	<p class="sgi-card__subtitle"><?php echo esc_html( $primary_meta ); ?></p>
	<?php if ( ! empty( $secondary_meta ) ) : ?>
		<p class="sgi-card__meta"><?php echo esc_html( $secondary_meta ); ?></p>
	<?php endif; ?>

	<div class="sgi-card__footer">
		<span class="sgi-badge sgi-badge--rarity" style="--rarity-color: <?php echo esc_attr( $item['rarity_color'] ? $item['rarity_color'] : '#7f8ea3' ); ?>;">
			<?php echo esc_html( ! empty( $item['rarity'] ) ? $item['rarity'] : __( 'Standard', 'steam-game-inventory' ) ); ?>
		</span>
		<span class="sgi-badge sgi-badge--price"><?php echo esc_html( $item['market_price'] ); ?></span>
	</div>

	<?php if ( ! empty( $item['stattrak'] ) ) : ?>
		<span class="sgi-card__stattrak"><?php echo esc_html__( 'StatTrak', 'steam-game-inventory' ); ?></span>
	<?php endif; ?>
</article>
