<?php

namespace SGI\Core;

/**
 * PSR-4 style autoloader for SGI namespace.
 */
class Autoloader {

	/**
	 * Register autoload callback.
	 *
	 * @return void
	 */
	public function register() {
		spl_autoload_register( array( $this, 'autoload' ) );
	}

	/**
	 * Load class file.
	 *
	 * @param string $class Class name.
	 * @return void
	 */
	private function autoload( $class ) {
		$prefix = 'SGI\\';

		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}

		$relative = substr( $class, strlen( $prefix ) );
		$relative = str_replace( '\\', '/', $relative );
		$path     = SGI_PLUGIN_PATH . 'src/' . $relative . '.php';

		if ( file_exists( $path ) ) {
			require_once $path;
		}
	}
}
