<?php

namespace SGI\Core;

/**
 * Lightweight service container.
 */
class Container {

	/**
	 * Service factories.
	 *
	 * @var array<string, callable>
	 */
	private $factories = array();

	/**
	 * Instantiated services.
	 *
	 * @var array<string, mixed>
	 */
	private $instances = array();

	/**
	 * Register service factory.
	 *
	 * @param string   $id Service id.
	 * @param callable $factory Factory callable.
	 * @return void
	 */
	public function set( $id, callable $factory ) {
		$this->factories[ $id ] = $factory;
	}

	/**
	 * Resolve service.
	 *
	 * @param string $id Service id.
	 * @return mixed
	 */
	public function get( $id ) {
		if ( isset( $this->instances[ $id ] ) ) {
			return $this->instances[ $id ];
		}

		if ( ! isset( $this->factories[ $id ] ) ) {
			return null;
		}

		$this->instances[ $id ] = call_user_func( $this->factories[ $id ], $this );
		return $this->instances[ $id ];
	}
}
