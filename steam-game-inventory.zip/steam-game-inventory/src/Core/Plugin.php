<?php

namespace SGI\Core;

use SGI\Controllers\Ajax_Controller;
use SGI\Services\Steam_API_Service;
use SGI\Services\Steam_Market_Service;
use SGI\Shortcodes\Inventory_Shortcode;

/**
 * Main plugin orchestrator.
 */
class Plugin {

	/**
	 * Service container.
	 *
	 * @var Container
	 */
	private $container;

	/**
	 * Bootstrap plugin.
	 *
	 * @return void
	 */
	public function boot() {
		$this->container = new Container();
		$this->register_services();
		$this->register_hooks();
	}

	/**
	 * Register dependency container services.
	 *
	 * @return void
	 */
	private function register_services() {
		$this->container->set(
			'steam_api_service',
			static function () {
				return new Steam_API_Service();
			}
		);

		$this->container->set(
			'steam_market_service',
			static function () {
				return new Steam_Market_Service();
			}
		);

		$this->container->set(
			'ajax_controller',
			function ( Container $container ) {
				return new Ajax_Controller(
					$container->get( 'steam_api_service' ),
					$container->get( 'steam_market_service' )
				);
			}
		);

		$this->container->set(
			'inventory_shortcode',
			function ( Container $container ) {
				return new Inventory_Shortcode( $container->get( 'ajax_controller' ) );
			}
		);
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		/** @var Ajax_Controller $ajax */
		$ajax = $this->container->get( 'ajax_controller' );
		$ajax->register_hooks();

		/** @var Inventory_Shortcode $shortcode */
		$shortcode = $this->container->get( 'inventory_shortcode' );
		$shortcode->register_hooks();
	}
}
