<?php

namespace SGI\Controllers;

use SGI\Services\Steam_API_Service;
use SGI\Services\Steam_Market_Service;

/**
 * Handles AJAX inventory loading.
 */
class Ajax_Controller {

	/**
	 * Steam inventory service.
	 *
	 * @var Steam_API_Service
	 */
	private $steam_api_service;

	/**
	 * Market service.
	 *
	 * @var Steam_Market_Service
	 */
	private $steam_market_service;

	/**
	 * Constructor.
	 *
	 * @param Steam_API_Service    $steam_api_service Steam API.
	 * @param Steam_Market_Service $steam_market_service Market service.
	 */
	public function __construct( Steam_API_Service $steam_api_service, Steam_Market_Service $steam_market_service ) {
		$this->steam_api_service    = $steam_api_service;
		$this->steam_market_service = $steam_market_service;
	}

	/**
	 * Register wordpress hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'wp_ajax_load_steam_inventory', array( $this, 'load_inventory' ) );
	}

	/**
	 * AJAX endpoint callback.
	 *
	 * @return void
	 */
	public function load_inventory() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'sgi_inventory_nonce' ) ) {
			wp_send_json_error(
				array(
					'html' => $this->render_error_card( __( 'Security validation failed. Please refresh and retry.', 'steam-game-inventory' ) ),
				)
			);
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error(
				array(
					'html' => $this->render_error_card( __( 'You must be logged in to view inventory.', 'steam-game-inventory' ) ),
				)
			);
		}

		if ( ! current_user_can( 'read' ) ) {
			wp_send_json_error(
				array(
					'html' => $this->render_error_card( __( 'You do not have permission to access this inventory.', 'steam-game-inventory' ) ),
				)
			);
		}

		$user_id  = get_current_user_id();
		$steam_id = get_user_meta( $user_id, 'steam_id', true );

		if ( empty( $steam_id ) ) {
			wp_send_json_error(
				array(
					'html' => $this->render_error_card( __( 'Steam account is not connected.', 'steam-game-inventory' ) ),
				)
			);
		}

		$appid  = isset( $_POST['appid'] ) ? absint( wp_unslash( $_POST['appid'] ) ) : 0;
		$result = $this->steam_api_service->get_inventory( $user_id, $steam_id, $appid );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error(
				array(
					'html' => $this->render_error_partial( $result['error_code'], $result['message'] ),
				)
			);
		}

		$items = $this->steam_market_service->hydrate_prices( $user_id, $appid, $result['items'] );
		if ( empty( $items ) ) {
			wp_send_json_success(
				array(
					'html' => $this->render_error_partial( 'empty', __( 'No items were found in this inventory.', 'steam-game-inventory' ) ),
				)
			);
		}

		ob_start();
		foreach ( $items as $item ) {
			include SGI_PLUGIN_PATH . 'templates/partials/item-card.php';
		}
		$html = ob_get_clean();

		wp_send_json_success(
			array(
				'html'  => $html,
				'count' => count( $items ),
			)
		);
	}

	/**
	 * Render error template partial.
	 *
	 * @param string $error_code Error slug.
	 * @param string $message Error message.
	 * @return string
	 */
	public function render_error_partial( $error_code, $message ) {
		$error_code = sanitize_text_field( $error_code );
		$message    = sanitize_text_field( $message );
		ob_start();
		include SGI_PLUGIN_PATH . 'templates/partials/error-state.php';
		return ob_get_clean();
	}

	/**
	 * Render generic error card.
	 *
	 * @param string $message Error message.
	 * @return string
	 */
	private function render_error_card( $message ) {
		return $this->render_error_partial( 'generic', $message );
	}
}
