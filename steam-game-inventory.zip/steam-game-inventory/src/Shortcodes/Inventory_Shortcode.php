<?php

namespace SGI\Shortcodes;

use SGI\Controllers\Ajax_Controller;

/**
 * Handles inventory shortcode rendering.
 */
class Inventory_Shortcode {

	/**
	 * Ajax controller.
	 *
	 * @var Ajax_Controller
	 */
	private $ajax_controller;

	/**
	 * Constructor.
	 *
	 * @param Ajax_Controller $ajax_controller Ajax controller.
	 */
	public function __construct( Ajax_Controller $ajax_controller ) {
		$this->ajax_controller = $ajax_controller;
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_shortcode( 'steam_game_inventory', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
	}

	/**
	 * Register scripts and styles.
	 *
	 * @return void
	 */
	public function register_assets() {
		wp_register_style(
			'sgi-inventory-style',
			SGI_PLUGIN_URL . 'assets/css/inventory.css',
			array(),
			SGI_PLUGIN_VERSION
		);

		wp_register_script(
			'sgi-inventory-script',
			SGI_PLUGIN_URL . 'assets/js/inventory.js',
			array(),
			SGI_PLUGIN_VERSION,
			true
		);
	}

	/**
	 * Render shortcode output.
	 *
	 * @return string
	 */
	public function render_shortcode() {
		if ( ! is_user_logged_in() ) {
			return $this->ajax_controller->render_error_partial( 'login_required', __( 'Please log in to view your Steam inventory.', 'steam-game-inventory' ) );
		}

		$user_id  = get_current_user_id();
		$steam_id = get_user_meta( $user_id, 'steam_id', true );
		if ( empty( $steam_id ) ) {
			return $this->ajax_controller->render_error_partial( 'steam_not_connected', __( 'Connect your Steam account to see your inventory.', 'steam-game-inventory' ) );
		}

		wp_enqueue_style( 'sgi-inventory-style' );
		wp_enqueue_script( 'sgi-inventory-script' );

		wp_localize_script(
			'sgi-inventory-script',
			'sgiInventoryConfig',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'sgi_inventory_nonce' ),
				'appids'  => array( 570, 730, 440 ),
			)
		);

		ob_start();
		include SGI_PLUGIN_PATH . 'templates/inventory-tabs.php';
		return ob_get_clean();
	}
}
