<?php

namespace SGI\Services;

/**
 * Communicates with Steam inventory API and normalizes item payloads.
 */
class Steam_API_Service {

	/**
	 * Supported App IDs.
	 *
	 * @var int[]
	 */
	private $supported_appids = array( 570, 730, 440 );

	/**
	 * Fetch and normalize inventory for user/game.
	 *
	 * @param int $user_id Current WP user id.
	 * @param string $steam_id Connected steam id.
	 * @param int $appid Steam app id.
	 * @return array<string,mixed>
	 */
	public function get_inventory( $user_id, $steam_id, $appid ) {
		$appid = absint( $appid );
		if ( ! in_array( $appid, $this->supported_appids, true ) ) {
			return array( 'success' => false, 'error_code' => 'invalid_app', 'message' => __( 'Invalid game selected.', 'steam-game-inventory' ) );
		}

		$cache_key = sprintf( 'sgi_inv_%d_%d', absint( $user_id ), $appid );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$url      = sprintf( 'https://steamcommunity.com/inventory/%s/%d/2?l=english&count=2000', rawurlencode( $steam_id ), $appid );
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'headers' => array(
					'Accept' => 'application/json',
				),
			)
		);

		$result = $this->handle_response( $response, $appid );
		set_transient( $cache_key, $result, 5 * MINUTE_IN_SECONDS );
		return $result;
	}

	/**
	 * Handle steam API response.
	 *
	 * @param array|\WP_Error $response HTTP response.
	 * @param int             $appid App ID.
	 * @return array<string,mixed>
	 */
	private function handle_response( $response, $appid ) {
		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'error_code' => 'request_failed', 'message' => __( 'Steam inventory request failed.', 'steam-game-inventory' ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( 429 === $code ) {
			return array( 'success' => false, 'error_code' => 'rate_limited', 'message' => __( 'Steam API is rate limiting requests. Please retry shortly.', 'steam-game-inventory' ) );
		}

		if ( 403 === $code ) {
			return array( 'success' => false, 'error_code' => 'private_inventory', 'message' => __( 'Inventory is private.', 'steam-game-inventory' ) );
		}

		if ( 200 !== $code ) {
			return array( 'success' => false, 'error_code' => 'api_error', 'message' => __( 'Steam API returned an unexpected response.', 'steam-game-inventory' ) );
		}

		$decoded = json_decode( $body, true );
		if ( empty( $decoded ) || ! is_array( $decoded ) ) {
			return array( 'success' => false, 'error_code' => 'invalid_response', 'message' => __( 'Steam API returned invalid data.', 'steam-game-inventory' ) );
		}

		if ( ! empty( $decoded['success'] ) && isset( $decoded['assets'] ) && isset( $decoded['descriptions'] ) ) {
			$items = $this->normalize_items( $decoded['assets'], $decoded['descriptions'], $appid );
			if ( empty( $items ) ) {
				return array( 'success' => true, 'error_code' => '', 'message' => '', 'items' => array(), 'meta' => array( 'count' => 0 ) );
			}
			return array( 'success' => true, 'error_code' => '', 'message' => '', 'items' => $items, 'meta' => array( 'count' => count( $items ) ) );
		}

		if ( isset( $decoded['success'] ) && (int) $decoded['success'] === 0 ) {
			return array( 'success' => false, 'error_code' => 'private_inventory', 'message' => __( 'Inventory is private or unavailable.', 'steam-game-inventory' ) );
		}

		return array( 'success' => false, 'error_code' => 'api_error', 'message' => __( 'Unable to parse inventory response.', 'steam-game-inventory' ) );
	}

	/**
	 * Normalize steam inventory items.
	 *
	 * @param array<int,array<string,mixed>> $assets Assets.
	 * @param array<int,array<string,mixed>> $descriptions Descriptions.
	 * @param int                            $appid AppID.
	 * @return array<int,array<string,mixed>>
	 */
	private function normalize_items( array $assets, array $descriptions, $appid ) {
		$description_map = array();
		foreach ( $descriptions as $description ) {
			$key                    = $description['classid'] . '_' . $description['instanceid'];
			$description_map[ $key ] = $description;
		}

		$normalized = array();
		foreach ( $assets as $asset ) {
			$key = $asset['classid'] . '_' . $asset['instanceid'];
			if ( ! isset( $description_map[ $key ] ) ) {
				continue;
			}

			$description = $description_map[ $key ];
			$tags        = isset( $description['tags'] ) && is_array( $description['tags'] ) ? $description['tags'] : array();

			$base = array(
				'asset_id'          => isset( $asset['assetid'] ) ? sanitize_text_field( $asset['assetid'] ) : '',
				'appid'             => absint( $appid ),
				'item_name'         => isset( $description['name'] ) ? sanitize_text_field( $description['name'] ) : '',
				'market_hash_name'  => isset( $description['market_hash_name'] ) ? sanitize_text_field( $description['market_hash_name'] ) : '',
				'icon_url'          => ! empty( $description['icon_url'] ) ? sprintf( 'https://community.cloudflare.steamstatic.com/economy/image/%s/360fx360f', rawurlencode( $description['icon_url'] ) ) : '',
				'marketable'        => ! empty( $description['marketable'] ),
				'type'              => isset( $description['type'] ) ? sanitize_text_field( $description['type'] ) : '',
				'rarity'            => $this->extract_tag_value( $tags, array( 'Rarity', 'Grade' ) ),
				'rarity_color'      => ! empty( $description['name_color'] ) ? '#' . sanitize_hex_color_no_hash( $description['name_color'] ) : '',
				'tags'              => $tags,
			);

			$normalized[] = $this->normalize_by_game( $base, $tags, $appid );
		}

		return $normalized;
	}

	/**
	 * Game-specific normalization.
	 *
	 * @param array<string,mixed> $base Base item payload.
	 * @param array<int,array<string,mixed>> $tags Steam tags.
	 * @param int $appid Steam app id.
	 * @return array<string,mixed>
	 */
	private function normalize_by_game( array $base, array $tags, $appid ) {
		if ( 570 === $appid ) {
			$base['hero'] = $this->extract_tag_value( $tags, array( 'Hero' ) );
		}

		if ( 730 === $appid ) {
			$base['weapon']   = $this->extract_weapon_name( $base['item_name'] );
			$base['skin']     = $this->extract_skin_name( $base['item_name'] );
			$base['exterior'] = $this->extract_tag_value( $tags, array( 'Exterior' ) );
			$base['stattrak'] = false !== stripos( $base['item_name'], 'StatTrak' );
		}

		if ( 440 === $appid ) {
			$base['quality'] = $this->extract_tag_value( $tags, array( 'Quality' ) );
		}

		return $base;
	}

	/**
	 * Extract tag value by category names.
	 *
	 * @param array<int,array<string,mixed>> $tags Steam tags.
	 * @param array<int,string>              $categories Categories.
	 * @return string
	 */
	private function extract_tag_value( array $tags, array $categories ) {
		foreach ( $tags as $tag ) {
			if ( empty( $tag['category'] ) || empty( $tag['localized_tag_name'] ) ) {
				continue;
			}

			if ( in_array( $tag['category'], $categories, true ) ) {
				return sanitize_text_field( $tag['localized_tag_name'] );
			}
		}

		return '';
	}

	/**
	 * Extract CS weapon name.
	 *
	 * @param string $item_name Item name.
	 * @return string
	 */
	private function extract_weapon_name( $item_name ) {
		$parts = array_map( 'trim', explode( '|', $item_name ) );
		return ! empty( $parts[0] ) ? sanitize_text_field( $parts[0] ) : '';
	}

	/**
	 * Extract CS skin name.
	 *
	 * @param string $item_name Item name.
	 * @return string
	 */
	private function extract_skin_name( $item_name ) {
		$parts = array_map( 'trim', explode( '|', $item_name ) );
		return ! empty( $parts[1] ) ? sanitize_text_field( $parts[1] ) : '';
	}
}
