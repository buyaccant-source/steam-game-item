<?php

namespace SGI\Services;

/**
 * Fetches Steam market prices with caching.
 */
class Steam_Market_Service {

	/**
	 * Resolve prices for normalized items.
	 *
	 * @param int   $user_id User id.
	 * @param int   $appid App id.
	 * @param array<int,array<string,mixed>> $items Items.
	 * @return array<int,array<string,mixed>>
	 */
	public function hydrate_prices( $user_id, $appid, array $items ) {
		$resolved = array();
		$queue    = array();

		foreach ( $items as $index => $item ) {
			$item['market_price'] = __( 'N/A', 'steam-game-inventory' );
			if ( empty( $item['marketable'] ) || empty( $item['market_hash_name'] ) ) {
				$resolved[ $index ] = $item;
				continue;
			}

			$cache_key = $this->build_cache_key( $user_id, $appid, $item['market_hash_name'] );
			$cached    = get_transient( $cache_key );
			if ( false !== $cached ) {
				$item['market_price'] = $cached;
				$resolved[ $index ]   = $item;
				continue;
			}

			$item['__cache_key'] = $cache_key;
			$resolved[ $index ]  = $item;
			$queue[]             = $index;
		}

		foreach ( $queue as $index ) {
			$item                  = $resolved[ $index ];
			$price                 = $this->fetch_price( $appid, $item['market_hash_name'] );
			$resolved[ $index ]['market_price'] = $price;
			set_transient( $item['__cache_key'], $price, 15 * MINUTE_IN_SECONDS );
			unset( $resolved[ $index ]['__cache_key'] );
		}

		ksort( $resolved );
		return array_values( $resolved );
	}

	/**
	 * Fetch market price overview.
	 *
	 * @param int    $appid AppID.
	 * @param string $market_hash_name Market hash name.
	 * @return string
	 */
	private function fetch_price( $appid, $market_hash_name ) {
		$url = add_query_arg(
			array(
				'currency'     => 1,
				'appid'        => absint( $appid ),
				'market_hash_name' => rawurlencode( $market_hash_name ),
			),
			'https://steamcommunity.com/market/priceoverview/'
		);

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 15,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return __( 'Unavailable', 'steam-game-inventory' );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return __( 'Unavailable', 'steam-game-inventory' );
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $decoded['success'] ) ) {
			return __( 'Unavailable', 'steam-game-inventory' );
		}

		if ( ! empty( $decoded['lowest_price'] ) ) {
			return sanitize_text_field( $decoded['lowest_price'] );
		}

		if ( ! empty( $decoded['median_price'] ) ) {
			return sanitize_text_field( $decoded['median_price'] );
		}

		return __( 'Unavailable', 'steam-game-inventory' );
	}

	/**
	 * Build stable transient key.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $appid App id.
	 * @param string $market_hash_name Market hash name.
	 * @return string
	 */
	private function build_cache_key( $user_id, $appid, $market_hash_name ) {
		return 'sgi_price_' . absint( $user_id ) . '_' . absint( $appid ) . '_' . md5( wp_json_encode( $market_hash_name ) );
	}
}
