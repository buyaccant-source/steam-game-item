<?php
/**
 * Plugin Name: Steam Game Inventory
 * Description: Premium Steam inventory display plugin for connected WordPress users.
 * Version: 1.0.0
 * Author: Steam Inventory Team
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: steam-game-inventory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SGI_PLUGIN_VERSION', '1.0.0' );
define( 'SGI_PLUGIN_FILE', __FILE__ );
define( 'SGI_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'SGI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once SGI_PLUGIN_PATH . 'src/Core/Autoloader.php';

$sgi_autoloader = new SGI\Core\Autoloader();
$sgi_autoloader->register();

add_action(
	'plugins_loaded',
	static function () {
		$plugin = new SGI\Core\Plugin();
		$plugin->boot();
	}
);
