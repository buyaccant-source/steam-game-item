(() => {
	const root = document.querySelector('[data-component="sgi-inventory"]');
	if (!root || typeof sgiInventoryConfig === 'undefined') {
		return;
	}

	const tabs = Array.from(root.querySelectorAll('.sgi-tabs__button'));
	const indicator = root.querySelector('.sgi-tabs__indicator');
	const content = root.querySelector('[data-inventory-content]');
	const cache = new Map();
	let activeRequest = null;

	const skeletonMarkup = `
		<div class="sgi-grid sgi-grid--skeleton">
			${Array.from({ length: 6 }).map(() => '<div class="sgi-card sgi-card--skeleton"></div>').join('')}
		</div>
	`;

	const updateIndicator = (button) => {
		if (!indicator || !button) {
			return;
		}
		indicator.style.width = `${button.offsetWidth}px`;
		indicator.style.transform = `translateX(${button.offsetLeft}px)`;
	};

	const renderHtml = (html) => {
		content.innerHTML = `<div class="sgi-grid">${html}</div>`;
	};

	const loadInventory = async (appid) => {
		if (cache.has(appid)) {
			renderHtml(cache.get(appid));
			return;
		}

		if (activeRequest) {
			activeRequest.abort();
		}

		activeRequest = new AbortController();
		content.innerHTML = skeletonMarkup;

		const body = new URLSearchParams({
			action: 'load_steam_inventory',
			nonce: sgiInventoryConfig.nonce,
			appid: String(appid)
		});

		try {
			const response = await fetch(sgiInventoryConfig.ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body,
				signal: activeRequest.signal
			});
			const payload = await response.json();
			if (!payload || !payload.data || !payload.data.html) {
				throw new Error('Invalid response');
			}

			cache.set(appid, payload.data.html);
			renderHtml(payload.data.html);
		} catch (error) {
			if (error.name === 'AbortError') {
				return;
			}
			content.innerHTML = '<div class="sgi-error"><div class="sgi-error__content"><h3 class="sgi-error__title">Network error</h3><p class="sgi-error__message">Unable to load inventory. Please retry.</p></div></div>';
		}
	};

	tabs.forEach((tab) => {
		tab.addEventListener('click', () => {
			tabs.forEach((btn) => {
				btn.classList.remove('is-active');
				btn.setAttribute('aria-selected', 'false');
			});

			tab.classList.add('is-active');
			tab.setAttribute('aria-selected', 'true');
			updateIndicator(tab);
			loadInventory(Number(tab.dataset.appid));
		});
	});

	window.addEventListener('resize', () => {
		updateIndicator(root.querySelector('.sgi-tabs__button.is-active'));
	});

	const firstTab = root.querySelector('.sgi-tabs__button.is-active');
	updateIndicator(firstTab);
	if (firstTab) {
		loadInventory(Number(firstTab.dataset.appid));
	}
})();
